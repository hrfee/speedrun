# Speedrun
Grabs speedrun data from [speedrun.com](https://speedrun.com) and run times since the release of a chosen game.

# Install
```
git clone https://github.com/hrfee/speedrun.git
cd speedrun
poetry build
pip install dist/<package name

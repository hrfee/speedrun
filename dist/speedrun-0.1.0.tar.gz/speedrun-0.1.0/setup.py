# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['speedrun']

package_data = \
{'': ['*'], 'speedrun': ['templates/*']}

install_requires = \
['Flask>=1.1.2,<2.0.0',
 'pandas>=1.0.5,<2.0.0',
 'plotly>=4.8.2,<5.0.0',
 'srcomapi>=0.3.1,<0.4.0',
 'waitress>=1.4.4,<2.0.0']

entry_points = \
{'console_scripts': ['speedrun-serve = speedrun:main']}

setup_kwargs = {
    'name': 'speedrun',
    'version': '0.1.0',
    'description': 'Plots speedrun times since a games release.',
    'long_description': '# Speedrun\nGrabs speedrun data from [speedrun.com](https://speedrun.com) and run times since the release of a chosen game.\n\n# Install\n```\ngit clone https://github.com/hrfee/speedrun.git\ncd speedrun\npoetry build\npip install dist/<package name\n',
    'author': 'Harvey Tindall',
    'author_email': 'harveyltindall@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/hrfee/speedrun',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6.1,<4.0.0',
}


setup(**setup_kwargs)
